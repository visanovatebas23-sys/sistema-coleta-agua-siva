# SIVA — Sistema Integrado de Vigilância Ambiental

Aplicação web da Vigilância Ambiental de Nova Tebas para registro, gestão e monitoramento de coletas de água.

## Uso local

Execute `iniciar.bat` e abra `http://localhost:8080`. Não abra o `index.html` diretamente: GPS, câmera e armazenamento offline funcionam melhor em `localhost` ou HTTPS.

## Publicação online — Supabase + Vercel

### 1. Criar o banco e a autenticação

1. Crie um projeto no [Supabase](https://supabase.com).
2. No menu **SQL Editor**, execute o arquivo `supabase/schema.sql` inteiro.
3. Em **Authentication > Providers**, habilite e-mail e senha.
4. Crie o primeiro usuário em **Authentication > Users**.
5. Copie o UUID desse usuário e execute no SQL Editor o comando indicado no final de `schema.sql` para torná-lo **Administrador**.
6. Crie os demais usuários pelo painel do Supabase. O administrador define os perfis em `profiles`.

### 2. Configurar o aplicativo

1. Abra `config.js`.
2. Em **Project settings > API** no Supabase, copie a URL do projeto e a chave **Publishable** (ou `anon`).
3. Cole os valores em `url` e `publishableKey`.

> Nunca use a chave `service_role` no `config.js`, no site ou no navegador.

### 3. Publicar o site

1. Crie uma conta da Prefeitura no [Vercel](https://vercel.com) e conecte um repositório GitHub com esta pasta.
2. Importe o projeto no Vercel, sem comando de build e com a pasta atual como diretório raiz.
3. Clique em **Deploy**. O Vercel fornecerá uma URL HTTPS, necessária para GPS no celular.
4. No Supabase, em **Authentication > URL Configuration**, cadastre a URL do Vercel como URL do site e redirecionamento permitido.
5. Se houver domínio da Prefeitura, associe-o ao projeto Vercel — por exemplo, `siva.novatebas.pr.gov.br`.

## Perfis de acesso

- **Administrador:** usuários, configurações, correções e exclusões.
- **Coordenador:** consulta e correção de coletas.
- **Técnico da Vigilância:** cadastro e consulta de coletas.
- **Somente consulta:** visualização e relatórios.

O banco aplica essas permissões por regras de segurança (RLS), não apenas pela tela do sistema. A base segue o padrão oficial de autenticação e RLS do Supabase. [Supabase Auth](https://supabase.com/docs/guides/auth) e [RLS](https://supabase.com/docs/guides/database/postgres/row-level-security).
