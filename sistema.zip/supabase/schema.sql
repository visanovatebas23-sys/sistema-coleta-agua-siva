-- SIVA - Banco de dados, autenticação e permissões
-- Execute todo este arquivo no SQL Editor do projeto Supabase.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default 'Usuário SIVA',
  role text not null default 'Técnico da Vigilância'
    check (role in ('Administrador','Coordenador','Técnico da Vigilância','Somente Consulta')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'name', split_part(new.email, '@', 1)));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_manager()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role in ('Administrador','Coordenador')
  );
$$;

create table if not exists public.collections (
  id uuid primary key,
  sample_number text not null,
  payload jsonb not null,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists collections_sample_number_idx on public.collections(sample_number);
create index if not exists collections_created_at_idx on public.collections(created_at desc);

create table if not exists public.collection_audit (
  id bigint generated always as identity primary key,
  collection_id uuid not null,
  action text not null,
  changed_by uuid references auth.users(id),
  changed_at timestamptz not null default now(),
  previous_payload jsonb,
  current_payload jsonb
);

create or replace function public.audit_collection_change()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    insert into public.collection_audit(collection_id, action, changed_by, current_payload)
    values (new.id, 'Coleta cadastrada', auth.uid(), new.payload);
    return new;
  elsif tg_op = 'UPDATE' then
    insert into public.collection_audit(collection_id, action, changed_by, previous_payload, current_payload)
    values (new.id, 'Coleta corrigida', auth.uid(), old.payload, new.payload);
    return new;
  else
    insert into public.collection_audit(collection_id, action, changed_by, previous_payload)
    values (old.id, 'Coleta excluída', auth.uid(), old.payload);
    return old;
  end if;
end;
$$;

drop trigger if exists collection_audit_trigger on public.collections;
create trigger collection_audit_trigger after insert or update or delete on public.collections
for each row execute procedure public.audit_collection_change();

alter table public.profiles enable row level security;
alter table public.collections enable row level security;
alter table public.collection_audit enable row level security;

create policy "authenticated users can read profiles" on public.profiles
for select to authenticated using (true);
create policy "managers can update profiles" on public.profiles
for update to authenticated using (public.is_manager()) with check (public.is_manager());

create policy "authenticated users can read collections" on public.collections
for select to authenticated using (true);
create policy "authenticated users can create collections" on public.collections
for insert to authenticated with check (created_by = auth.uid());
create policy "owner or manager can update collection" on public.collections
for update to authenticated using (created_by = auth.uid() or public.is_manager())
with check (created_by = auth.uid() or public.is_manager());
create policy "only administrators can delete collection" on public.collections
for delete to authenticated using (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'Administrador')
);
create policy "managers can read audit log" on public.collection_audit
for select to authenticated using (public.is_manager());

-- Depois de criar o primeiro usuário no menu Authentication > Users, execute:
-- update public.profiles set role = 'Administrador' where id = 'UUID_DO_PRIMEIRO_GESTOR';
-- Os demais usuários serão criados pelo painel Authentication e receberão o perfil
-- Técnico da Vigilância. Um administrador pode promover perfis na tabela profiles.
