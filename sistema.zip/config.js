/*
  Configuração da publicação online.
  Preencha apenas depois de criar o projeto Supabase.
  Use a Publishable key (ou anon key). NUNCA inclua service_role neste arquivo.
*/
window.SIVA_SUPABASE = {
  url: 'COLE_AQUI_A_URL_DO_PROJETO',
  publishableKey: 'COLE_AQUI_A_CHAVE_PUBLICA'
};
