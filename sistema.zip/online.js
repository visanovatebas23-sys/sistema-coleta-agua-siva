(() => {
  const cfg = window.SIVA_SUPABASE;
  const configured = cfg && cfg.url && cfg.publishableKey && !cfg.url.includes('COLE_AQUI') && !cfg.publishableKey.includes('COLE_AQUI');
  if (!configured || !window.supabase?.createClient) return;

  const client = window.supabase.createClient(cfg.url, cfg.publishableKey, { auth: { persistSession: true, autoRefreshToken: true } });
  const KEY = 'nova-tebas-water-v1';
  const CONFIG_KEY = 'nova-tebas-config-v1';
  const overlay = document.createElement('div');
  overlay.id = 'loginOverlay';
  overlay.innerHTML = `<form id="loginForm"><small>SIVA · Vigilância Ambiental</small><h2>Acesso ao sistema</h2><p>Entre com o e-mail e a senha cadastrados pela gestão.</p><label>E-mail<input type="email" name="email" autocomplete="email" required></label><label>Senha<input type="password" name="password" autocomplete="current-password" required></label><button class="primary">Entrar</button><p id="loginMessage" class="muted"></p></form>`;

  function showLogin(message = '') { document.body.append(overlay); document.querySelector('#loginMessage').textContent = message; }
  function syncProfile(profile) {
    const current = JSON.parse(localStorage.getItem(CONFIG_KEY) || '{"users":[],"communities":[],"points":[]}');
    current.current = { name: profile.name || 'Usuário SIVA', role: profile.role || 'Técnico da Vigilância' };
    localStorage.setItem(CONFIG_KEY, JSON.stringify(current));
  }
  async function hydrate() {
    const { data: { user } } = await client.auth.getUser();
    if (!user) { showLogin(); return; }
    const [{ data: profile }, { data: collections, error }] = await Promise.all([
      client.from('profiles').select('name, role').eq('id', user.id).single(),
      client.from('collections').select('payload').order('created_at', { ascending: false })
    ]);
    if (error) { console.error('Erro ao sincronizar coletas:', error.message); return; }
    if (profile) syncProfile(profile);
    if (collections) {
      localStorage.setItem(KEY, JSON.stringify(collections.map(item => item.payload)));
      window.dispatchEvent(new Event('siva:sync'));
    }
  }
  overlay.addEventListener('submit', async event => {
    event.preventDefault();
    const fd = new FormData(event.currentTarget);
    const message = document.querySelector('#loginMessage');
    message.textContent = 'Entrando…';
    const { error } = await client.auth.signInWithPassword({ email: fd.get('email'), password: fd.get('password') });
    if (error) { message.textContent = 'Não foi possível entrar: ' + error.message; return; }
    overlay.remove(); await hydrate(); location.reload();
  });
  window.SIVA_ONLINE = {
    active: true,
    async queueCollections(list) {
      const { data: { user } } = await client.auth.getUser();
      if (!user || !list?.length) return;
      const rows = list.map(item => ({ id: item.id, sample_number: item.sample, payload: item, created_by: user.id, updated_at: new Date().toISOString() }));
      const { error } = await client.from('collections').upsert(rows, { onConflict: 'id' });
      if (error) console.error('Sincronização pendente:', error.message);
    },
    async deleteCollection(id) {
      const { error } = await client.from('collections').delete().eq('id', id);
      if (error) console.error('Exclusão não sincronizada:', error.message);
    },
    client
  };
  document.addEventListener('DOMContentLoaded', hydrate);
})();
